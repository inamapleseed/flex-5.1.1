$(document).ready(function(){
  $('div[data-has-toggle-option]').click(function(){
    $(this).siblings().children('.faceted-filter-group-display').slideToggle();
  })
})